package model;

import java.util.Date;

public class Historico {
    private int id;
    private int idUsuario;
    private String termoPesquisa;
    private Date dataPesquisa;

    public Historico() {}

    public Historico(int idUsuario, String termoPesquisa) {
        this.idUsuario = idUsuario;
        this.termoPesquisa = termoPesquisa;
        this.dataPesquisa = new Date();
    }

    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public int getIdUsuario() {
        return idUsuario;
    }
    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }
    public String getTermoPesquisa() {
        return termoPesquisa;
    }
    public void setTermoPesquisa(String termoPesquisa) {
        this.termoPesquisa = termoPesquisa;
    }
    public Date getDataPesquisa() {
        return dataPesquisa;
    }
    public void setDataPesquisa(Date dataPesquisa) {
        this.dataPesquisa = dataPesquisa;
    }
}
