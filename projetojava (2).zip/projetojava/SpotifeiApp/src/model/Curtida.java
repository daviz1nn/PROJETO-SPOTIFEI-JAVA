package model;

import java.sql.Timestamp;

public class Curtida {
    private int id;
    private int usuarioId;
    private int musicaId;
    private boolean curtido;
    private Timestamp dataCurtida;

    public Curtida(int usuarioId, int musicaId, boolean curtido) {
        this.usuarioId = usuarioId;
        this.musicaId = musicaId;
        this.curtido = curtido;
    }

    // Getters e Setters
    public int getUsuarioId() { return usuarioId; }
    public int getMusicaId() { return musicaId; }
    public boolean isCurtido() { return curtido; }
    public void setCurtido(boolean curtido) { this.curtido = curtido; }
}