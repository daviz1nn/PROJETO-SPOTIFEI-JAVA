package controller;

public class LoginController {

    private UsuarioController usuarioController;

    public LoginController() {
        usuarioController = new UsuarioController();
    }

    public int validarLogin(String email, String senha) {
        return usuarioController.validarLogin(email, senha);
    }
}
