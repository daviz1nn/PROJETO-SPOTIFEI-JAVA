package controller;

public class CadastroController {

    private UsuarioController usuarioController;

    public CadastroController() {
        usuarioController = new UsuarioController();
    }

    public boolean cadastrarUsuario(String nome, String email, String senha) {
        return usuarioController.cadastrarUsuario(nome, email, senha);
    }
}
