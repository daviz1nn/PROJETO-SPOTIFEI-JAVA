package controller;

import dao.MusicaDAO;
import model.Musica;

import java.util.List;

public class HomeController {

    private MusicaDAO musicaDAO;

    public HomeController() {
        musicaDAO = new MusicaDAO();
    }

    public List<Musica> buscarMusicas(String filtro) throws Exception {
        return musicaDAO.buscarMusicas(filtro);
    }


}
