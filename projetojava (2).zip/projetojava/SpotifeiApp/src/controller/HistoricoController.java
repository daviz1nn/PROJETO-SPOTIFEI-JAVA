package controller;

import dao.HistoricoDAO;
import model.Musica;

import java.sql.SQLException;
import java.util.List;

public class HistoricoController {
    private HistoricoDAO historicoDAO;

    public HistoricoController() {
        this.historicoDAO = new HistoricoDAO();
    }

    public List<Musica> obterHistoricoMusicas(int idUsuario) throws SQLException {
        return historicoDAO.obterHistoricoMusicas(idUsuario);
    }

    public void registrarPesquisa(int idUsuario, int idMusica) throws SQLException {
        historicoDAO.registrarPesquisa(idUsuario, idMusica);
    }
}
