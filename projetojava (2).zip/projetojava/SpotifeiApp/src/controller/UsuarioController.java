package controller;

import dao.UsuarioDAO;
import model.Usuario;

public class UsuarioController {

    private UsuarioDAO usuarioDAO;

    public UsuarioController() {
        usuarioDAO = new UsuarioDAO();
    }

    public boolean cadastrarUsuario(String nome, String email, String senha) {
        Usuario usuario = new Usuario();
        usuario.setNome(nome);
        usuario.setEmail(email);
        usuario.setSenha(senha);
        return usuarioDAO.cadastrarUsuario(usuario);
    }

    public int validarLogin(String email, String senha) {
        return usuarioDAO.validarLogin(email, senha);
    }
}
