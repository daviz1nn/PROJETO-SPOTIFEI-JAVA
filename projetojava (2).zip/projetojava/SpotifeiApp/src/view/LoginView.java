package view;

import controller.LoginController;
import javax.swing.*;

public class LoginView extends JFrame {
    private JTextField emailField;
    private JPasswordField senhaField;
    private JButton loginButton;
    private JButton cadastrarButton;
    private LoginController loginController;

    public LoginView() {
        loginController = new LoginController();

        setTitle("Login");
        setSize(350, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);

        JLabel emailLabel = new JLabel("Email:");
        emailLabel.setBounds(20, 20, 80, 25);
        add(emailLabel);

        emailField = new JTextField();
        emailField.setBounds(100, 20, 200, 25);
        add(emailField);

        JLabel senhaLabel = new JLabel("Senha:");
        senhaLabel.setBounds(20, 60, 80, 25);
        add(senhaLabel);

        senhaField = new JPasswordField();
        senhaField.setBounds(100, 60, 200, 25);
        add(senhaField);

        loginButton = new JButton("Login");
        loginButton.setBounds(50, 110, 100, 30);
        add(loginButton);

        cadastrarButton = new JButton("Cadastrar");
        cadastrarButton.setBounds(180, 110, 100, 30);
        add(cadastrarButton);

        // botão Login
        loginButton.addActionListener(e -> {
            String email = emailField.getText();
            String senha = new String(senhaField.getPassword());

            int usuarioId = loginController.validarLogin(email, senha);
            if (usuarioId > 0) {
                JOptionPane.showMessageDialog(this, "Bem vindo!");
                new HomeView(usuarioId).setVisible(true);
                this.dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Login inválido!");
            }
        });

        // botão Cadastrar
        cadastrarButton.addActionListener(e -> {
            new CadastroView().setVisible(true);
            this.dispose();
        });
    }
}