package dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Collections;
import model.Musica;

public class MusicaDAO {
    private Connection connection;

    public MusicaDAO() {
        this.connection = Conexao.getConnection();
    }

    
    public List<Musica> getMusicasPorPlaylist(int idPlaylist) {
        List<Musica> musicas = new ArrayList<>();
        String sql = "SELECT m.id, m.nome, m.artista, m.genero " +
                     "FROM musica m " +
                     "JOIN playlist_musica pm ON m.id = pm.id_musica " +
                     "WHERE pm.id_playlist = ?";

        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, idPlaylist);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Musica musica = new Musica(
                    rs.getInt("id"),
                    rs.getString("nome"),
                    rs.getString("artista"),
                    rs.getString("genero")
                );
                musicas.add(musica);
            }
        } catch (SQLException e) {
            System.err.println("Erro ao buscar músicas da playlist ID " + idPlaylist + ": " + e.getMessage());
        }
        return musicas;
    }

    // Métodos existentes (mantidos sem alterações)
    public List<Musica> buscarMusicas(String termoBusca) {
        List<Musica> musicas = new ArrayList<>();
        try {
            String sql = "SELECT * FROM musica WHERE nome ILIKE ?";
            PreparedStatement stmt = connection.prepareStatement(sql);
            stmt.setString(1, "%" + termoBusca + "%");
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                Musica musica = new Musica(
                    rs.getInt("id"),
                    rs.getString("nome"),
                    rs.getString("artista"),
                    rs.getString("genero")
                );
                musicas.add(musica);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return musicas;
    }

    public List<Musica> getMusicasPorIds(List<Integer> idsMusicas) {
        List<Musica> musicas = new ArrayList<>();
        if (idsMusicas.isEmpty()) return musicas;

        try {
            String placeholders = String.join(",", Collections.nCopies(idsMusicas.size(), "?"));
            String sql = "SELECT * FROM musica WHERE id IN (" + placeholders + ")";
            PreparedStatement stmt = connection.prepareStatement(sql);
            
            for (int i = 0; i < idsMusicas.size(); i++) {
                stmt.setInt(i + 1, idsMusicas.get(i));
            }
            
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Musica musica = new Musica(
                    rs.getInt("id"),
                    rs.getString("nome"),
                    rs.getString("artista"),
                    rs.getString("genero")
                );
                musicas.add(musica);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return musicas;
    }
}