package dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class HistoricoDAO {

    public boolean salvarBusca(int idUsuario, int idMusica) throws SQLException {
        String sql = "INSERT INTO historico_busca (id_usuario, id_musica) VALUES (?, ?)";
        try (Connection con = Conexao.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, idUsuario);
            ps.setInt(2, idMusica);
            return ps.executeUpdate() > 0;
        }
    }

    public List<Integer> listarUltimasBuscas(int idUsuario, int limite) throws SQLException {
        List<Integer> musicas = new ArrayList<>();
        String sql = "SELECT id_musica FROM historico_busca WHERE id_usuario = ? ORDER BY data_busca DESC LIMIT ?";
        try (Connection con = Conexao.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, idUsuario);
            ps.setInt(2, limite);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    musicas.add(rs.getInt("id_musica"));
                }
            }
        }
        return musicas;
    }
}
