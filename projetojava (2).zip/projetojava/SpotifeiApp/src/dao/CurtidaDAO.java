package dao;

import dao.Conexao;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CurtidaDAO {
    private Connection connection;

    public CurtidaDAO() {
        connection = Conexao.getConnection();
    }

    // Método para curtir 
    public boolean curtir(int usuarioId, int musicaId) {
        try {
            // Verifica se já curtiu
            if (jaCurtiu(usuarioId, musicaId)) {
                return false;
            }
            
            // Insere a curtida
            String sql = "INSERT INTO curtida (id_usuario, id_musica, curtida) VALUES (?, ?, true)";
            PreparedStatement stmt = connection.prepareStatement(sql);
            stmt.setInt(1, usuarioId);
            stmt.setInt(2, musicaId);
            stmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    
    private boolean jaCurtiu(int usuarioId, int musicaId) {
        try {
            String sql = "SELECT 1 FROM curtida WHERE id_usuario = ? AND id_musica = ? AND curtida = true";
            PreparedStatement stmt = connection.prepareStatement(sql);
            stmt.setInt(1, usuarioId);
            stmt.setInt(2, musicaId);
            ResultSet rs = stmt.executeQuery();
            return rs.next();
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Método para descurtir
    public boolean descurtir(int usuarioId, int musicaId) {
        try {
            String sql = "DELETE FROM curtida WHERE id_usuario = ? AND id_musica = ?";
            PreparedStatement stmt = connection.prepareStatement(sql);
            stmt.setInt(1, usuarioId);
            stmt.setInt(2, musicaId);
            int rows = stmt.executeUpdate();
            return rows > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // músicas curtidas
    public List<Integer> getMusicasCurtidas(int usuarioId) {
        List<Integer> musicasCurtidas = new ArrayList<>();
        try {
            String sql = "SELECT id_musica FROM curtida WHERE id_usuario = ? AND curtida = true";
            PreparedStatement stmt = connection.prepareStatement(sql);
            stmt.setInt(1, usuarioId);
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                musicasCurtidas.add(rs.getInt("id_musica"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return musicasCurtidas;
    }
}