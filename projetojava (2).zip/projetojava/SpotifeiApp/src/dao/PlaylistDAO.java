package dao;

import model.Playlist;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PlaylistDAO {
    private Connection connection;

    public PlaylistDAO() {
        this.connection = Conexao.getConnection();
    }

    // Remove música da playlist
    public boolean removerMusicaDaPlaylist(int idPlaylist, int idMusica) {
        String sql = "DELETE FROM playlist_musica WHERE id_playlist = ? AND id_musica = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, idPlaylist);
            stmt.setInt(2, idMusica);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Erro ao remover música: " + e.getMessage());
            return false;
        }
    }

    // Cria nova playlist
    public boolean criarPlaylist(int usuarioId, String nome) {
        String sql = "INSERT INTO playlist (nome, id_usuario) VALUES (?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, nome);
            stmt.setInt(2, usuarioId);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

   
    public List<Playlist> getPlaylistsPorUsuario(int usuarioId) {
        List<Playlist> playlists = new ArrayList<>();
        String sql = "SELECT id, nome, id_usuario FROM playlist WHERE id_usuario = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, usuarioId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Playlist playlist = new Playlist();
                playlist.setId(rs.getInt("id"));
                playlist.setNome(rs.getString("nome"));
                playlist.setIdUsuario(rs.getInt("id_usuario"));
                playlists.add(playlist);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return playlists;
    }

    // Adiciona música p playlist
    public boolean adicionarMusicaNaPlaylist(int idPlaylist, int idMusica) {
        String sql = "INSERT INTO playlist_musica (id_playlist, id_musica) VALUES (?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, idPlaylist);
            stmt.setInt(2, idMusica);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    //ids das músicas da playlist
    public List<Integer> getIdsMusicasPorPlaylist(int idPlaylist) {
        List<Integer> idsMusicas = new ArrayList<>();
        String sql = "SELECT id_musica FROM playlist_musica WHERE id_playlist = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, idPlaylist);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                idsMusicas.add(rs.getInt("id_musica"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return idsMusicas;
    }

    // Excluir playlist 
    public boolean excluirPlaylist(int idPlaylist) {
        String sqlDeleteMusicas = "DELETE FROM playlist_musica WHERE id_playlist = ?";
        String sqlDeletePlaylist = "DELETE FROM playlist WHERE id = ?";
        
        try {
            connection.setAutoCommit(false);
            
            try (PreparedStatement stmt1 = connection.prepareStatement(sqlDeleteMusicas)) {
                stmt1.setInt(1, idPlaylist);
                stmt1.executeUpdate();
            }

            try (PreparedStatement stmt2 = connection.prepareStatement(sqlDeletePlaylist)) {
                stmt2.setInt(1, idPlaylist);
                int affectedRows = stmt2.executeUpdate();

                connection.commit();
                connection.setAutoCommit(true);
                return affectedRows > 0;
            }
        } catch (SQLException e) {
            try {
                connection.rollback();
                connection.setAutoCommit(true);
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            e.printStackTrace();
            return false;
        }
    }
}
