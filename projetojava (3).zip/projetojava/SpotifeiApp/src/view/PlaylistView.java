package view;

import controller.PlaylistController;
import model.Musica;
import model.Playlist;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.List;

public class PlaylistView extends JFrame {
    private PlaylistController playlistController;
    private JList<Playlist> playlistsList;
    private JList<Musica> musicasList;
    private Playlist playlistSelecionada;
    private Musica musicaSelecionada;
    private int usuarioId;

    public PlaylistView(int usuarioId) {
        this.usuarioId = usuarioId;
        this.playlistController = new PlaylistController();

        setTitle("Gerenciar Playlists");
        setSize(700, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // Painel principal
        JPanel painelListas = new JPanel(new GridLayout(1, 2, 10, 10));

        //LISTA DE PLAYLISTS 
        playlistsList = new JList<>();
        playlistsList.addListSelectionListener(e -> {
            playlistSelecionada = playlistsList.getSelectedValue();
            atualizarListaMusicas();
        });
        painelListas.add(new JScrollPane(playlistsList));

        // LISTA DE MÚSICAS DA PLAYLIST
        musicasList = new JList<>();
        musicasList.addListSelectionListener(e -> {
            musicaSelecionada = musicasList.getSelectedValue();
        });
        painelListas.add(new JScrollPane(musicasList));

        add(painelListas, BorderLayout.CENTER);

        // BOToES
        JPanel painelBotoes = new JPanel(new GridLayout(1, 4, 10, 10));

        JButton criarButton = new JButton("Criar Playlist");
        criarButton.addActionListener(this::criarPlaylist);
        painelBotoes.add(criarButton);

        JButton adicionarButton = new JButton("Adicionar Música");
        adicionarButton.addActionListener(this::adicionarMusicaNaPlaylist);
        painelBotoes.add(adicionarButton);

        JButton removerButton = new JButton("Remover Música");
        removerButton.addActionListener(this::removerMusicaDaPlaylist);
        painelBotoes.add(removerButton);

        JButton excluirButton = new JButton("Excluir Playlist");
        excluirButton.addActionListener(this::excluirPlaylist);
        painelBotoes.add(excluirButton);

        add(painelBotoes, BorderLayout.SOUTH);

        carregarPlaylists();
        setVisible(true);
    }

    private void carregarPlaylists() {
        List<Playlist> playlists = playlistController.getPlaylistsDoUsuario(usuarioId);
        playlistsList.setListData(playlists.toArray(new Playlist[0]));
    }

    private void atualizarListaMusicas() {
        if (playlistSelecionada != null) {
            List<Musica> musicas = playlistController.getMusicasDaPlaylist(playlistSelecionada.getId());
            musicasList.setListData(musicas.toArray(new Musica[0]));
        }
    }

    private void criarPlaylist(ActionEvent e) {
        String nome = JOptionPane.showInputDialog(this, "Nome da nova playlist:");
        if (nome != null && !nome.isBlank()) {
            playlistController.criarPlaylist(usuarioId, nome);
            carregarPlaylists();
        }
    }

    private void adicionarMusicaNaPlaylist(ActionEvent e) {
        if (playlistSelecionada == null) {
            JOptionPane.showMessageDialog(this, "Selecione uma playlist!");
            return;
        }

        String idStr = JOptionPane.showInputDialog(this, "ID da música a adicionar:");
        try {
            int idMusica = Integer.parseInt(idStr);
            boolean sucesso = playlistController.adicionarMusicaNaPlaylist(playlistSelecionada.getId(), idMusica);

            if (sucesso) {
                JOptionPane.showMessageDialog(this, "Música adicionada!");
                atualizarListaMusicas();
            } else {
                JOptionPane.showMessageDialog(this, "Erro ao adicionar música.");
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "ID inválido.");
        }
    }

    private void removerMusicaDaPlaylist(ActionEvent e) {
        if (playlistSelecionada == null || musicaSelecionada == null) {
            JOptionPane.showMessageDialog(this, "Selecione uma playlist e uma música!");
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(this, "Remover '" + musicaSelecionada.getNome() + "'?", "Confirmar", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            boolean sucesso = playlistController.removerMusicaDaPlaylist(
                playlistSelecionada.getId(), musicaSelecionada.getId()
            );

            if (sucesso) {
                JOptionPane.showMessageDialog(this, "Música removida.");
                atualizarListaMusicas();
            } else {
                JOptionPane.showMessageDialog(this, "Erro ao remover.");
            }
        }
    }

    private void excluirPlaylist(ActionEvent e) {
        if (playlistSelecionada == null) {
            JOptionPane.showMessageDialog(this, "Selecione uma playlist para excluir!");
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(this, "Excluir a playlist '" + playlistSelecionada.getNome() + "'?", "Confirmar", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            boolean sucesso = playlistController.excluirPlaylist(playlistSelecionada.getId());
            if (sucesso) {
                JOptionPane.showMessageDialog(this, "Playlist excluída.");
                carregarPlaylists();
                musicasList.setListData(new Musica[0]); // limpa a lista de músicas
            } else {
                JOptionPane.showMessageDialog(this, "Erro ao excluir.");
            }
        }
    }
}
