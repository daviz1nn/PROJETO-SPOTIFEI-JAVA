package view;

import controller.CurtidaController;
import controller.MusicaController;
import controller.PlaylistController;
import model.Musica;
import model.Playlist;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.List;

public class HomeView extends JFrame {
    private JTextField campoBusca;
    private JButton botaoBuscar;
    private JList<Musica> listaMusicas;
    private JList<Musica> listaCurtidas;
    private DefaultListModel<Musica> listaMusicasModel;
    private DefaultListModel<Musica> listaCurtidasModel;
    private JButton botaoCurtir;
    private JButton botaoDescurtir;
    private JButton botaoAtualizarCurtidas;

    // Playlist
    private JList<Playlist> listaPlaylists;
    private DefaultListModel<Playlist> listaPlaylistsModel;
    private JButton botaoNovaPlaylist;
    private JButton botaoAtualizarPlaylists;
    private JButton botaoExcluirPlaylist; // novo botão para excluir playlist

    // Lista de músicas da playlist selecionada
    private JList<Musica> listaMusicasDaPlaylist;
    private DefaultListModel<Musica> listaMusicasDaPlaylistModel;
    private JButton botaoAdicionarMusicaNaPlaylist;
    private JButton botaoRemoverMusicaDaPlaylist; // botão para remover música da playlist

    private int usuarioId;

    private MusicaController musicaController;
    private CurtidaController curtidaController;
    private PlaylistController playlistController;

    public HomeView(int usuarioId) {
        this.usuarioId = usuarioId;
        this.musicaController = new MusicaController();
        this.curtidaController = new CurtidaController();
        this.playlistController = new PlaylistController();

        setTitle("Spotifei7 - Home");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1200, 550); 
        setLocationRelativeTo(null);

        initComponents();
        carregarMusicasCurtidas();
        carregarPlaylists();
    }

    private void initComponents() {
        // Painel de busca
        campoBusca = new JTextField(20);
        botaoBuscar = new JButton("Buscar");

        JPanel painelBusca = new JPanel();
        painelBusca.add(new JLabel("Buscar música:"));
        painelBusca.add(campoBusca);
        painelBusca.add(botaoBuscar);

        // Lista de músicas encontradas
        listaMusicasModel = new DefaultListModel<>();
        listaMusicas = new JList<>(listaMusicasModel);
        JScrollPane scrollPaneMusicas = new JScrollPane(listaMusicas);
        scrollPaneMusicas.setBorder(BorderFactory.createTitledBorder("Resultados da Busca"));

        // Lista de músicas curtidas
        listaCurtidasModel = new DefaultListModel<>();
        listaCurtidas = new JList<>(listaCurtidasModel);
        JScrollPane scrollPaneCurtidas = new JScrollPane(listaCurtidas);
        scrollPaneCurtidas.setBorder(BorderFactory.createTitledBorder("Suas Músicas Curtidas"));

        // Lista de playlists
        listaPlaylistsModel = new DefaultListModel<>();
        listaPlaylists = new JList<>(listaPlaylistsModel);
        JScrollPane scrollPanePlaylists = new JScrollPane(listaPlaylists);
        scrollPanePlaylists.setBorder(BorderFactory.createTitledBorder("Suas Playlists"));

        // Lista playlist selecionada
        listaMusicasDaPlaylistModel = new DefaultListModel<>();
        listaMusicasDaPlaylist = new JList<>(listaMusicasDaPlaylistModel);
        JScrollPane scrollPaneMusicasPlaylist = new JScrollPane(listaMusicasDaPlaylist);
        scrollPaneMusicasPlaylist.setBorder(BorderFactory.createTitledBorder("Músicas da Playlist Selecionada"));

        
        JPanel painelListas = new JPanel(new GridLayout(1, 4));
        painelListas.add(scrollPaneMusicas);
        painelListas.add(scrollPaneCurtidas);
        painelListas.add(scrollPanePlaylists);
        painelListas.add(scrollPaneMusicasPlaylist);

        // Botões de ação
        botaoCurtir = new JButton("Curtir");
        botaoDescurtir = new JButton("Descurtir");
        botaoAtualizarCurtidas = new JButton("Atualizar Curtidas");

        botaoNovaPlaylist = new JButton("Nova Playlist");
        botaoAtualizarPlaylists = new JButton("Atualizar Playlists");
        botaoExcluirPlaylist = new JButton("Excluir Playlist"); // botão excluir playlist

        botaoAdicionarMusicaNaPlaylist = new JButton("Adicionar Música na Playlist");
        botaoRemoverMusicaDaPlaylist = new JButton("Remover Música da Playlist"); // botão remover música da playlist

        JPanel painelBotoes = new JPanel();
        painelBotoes.add(botaoCurtir);
        painelBotoes.add(botaoDescurtir);
        painelBotoes.add(botaoAtualizarCurtidas);
        painelBotoes.add(botaoNovaPlaylist);
        painelBotoes.add(botaoAtualizarPlaylists);
        painelBotoes.add(botaoExcluirPlaylist);
        painelBotoes.add(botaoAdicionarMusicaNaPlaylist);
        painelBotoes.add(botaoRemoverMusicaDaPlaylist);

        // Layout principal
        add(painelBusca, BorderLayout.NORTH);
        add(painelListas, BorderLayout.CENTER);
        add(painelBotoes, BorderLayout.SOUTH);

        // Listeners
        botaoBuscar.addActionListener(this::buscarMusicas);
        botaoCurtir.addActionListener(e -> curtirMusica());
        botaoDescurtir.addActionListener(e -> descurtirMusica());
        botaoAtualizarCurtidas.addActionListener(e -> carregarMusicasCurtidas());
        botaoNovaPlaylist.addActionListener(e -> criarNovaPlaylist());
        botaoAtualizarPlaylists.addActionListener(e -> carregarPlaylists());
        botaoExcluirPlaylist.addActionListener(e -> excluirPlaylist()); //  excluir playlist
        botaoAdicionarMusicaNaPlaylist.addActionListener(e -> adicionarMusicaNaPlaylist());
        botaoRemoverMusicaDaPlaylist.addActionListener(e -> removerMusicaDaPlaylist()); // remover música da playlist

        
        listaPlaylists.addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                carregarMusicasDaPlaylistSelecionada();
            }
        });
    }

    private void buscarMusicas(ActionEvent e) {
        String termo = campoBusca.getText();
        try {
            List<Musica> musicas = musicaController.buscarMusicas(termo);
            listaMusicasModel.clear();
            for (Musica musica : musicas) {
                listaMusicasModel.addElement(musica);
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Erro ao buscar músicas: " + ex.getMessage());
        }
    }

    private void carregarMusicasCurtidas() {
        try {
            List<Integer> idsMusicas = curtidaController.getMusicasCurtidas(usuarioId);
            List<Musica> musicas = musicaController.getMusicasPorIds(idsMusicas);

            listaCurtidasModel.clear();
            for (Musica musica : musicas) {
                listaCurtidasModel.addElement(musica);
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Erro ao carregar músicas curtidas: " + ex.getMessage());
        }
    }

    private void carregarPlaylists() {
        try {
            List<Playlist> playlists = playlistController.getPlaylistsPorUsuario(usuarioId);
            listaPlaylistsModel.clear();
            for (Playlist p : playlists) {
                listaPlaylistsModel.addElement(p);
            }
            listaMusicasDaPlaylistModel.clear(); // limpa lista músicas da playlist ao atualizar playlists
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Erro ao carregar playlists: " + ex.getMessage());
        }
    }

    private void carregarMusicasDaPlaylistSelecionada() {
        Playlist playlistSelecionada = listaPlaylists.getSelectedValue();
        if (playlistSelecionada == null) {
            listaMusicasDaPlaylistModel.clear();
            return;
        }
        try {
            List<Musica> musicas = musicaController.getMusicasPorPlaylist(playlistSelecionada.getId());
            listaMusicasDaPlaylistModel.clear();
            for (Musica musica : musicas) {
                listaMusicasDaPlaylistModel.addElement(musica);
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Erro ao carregar músicas da playlist: " + ex.getMessage());
        }
    }

    private void curtirMusica() {
        Musica musicaSelecionada = listaMusicas.getSelectedValue();
        if (musicaSelecionada != null) {
            boolean sucesso = curtidaController.curtir(usuarioId, musicaSelecionada.getId());
            if (sucesso) {
                JOptionPane.showMessageDialog(this, "Música curtida!");
                carregarMusicasCurtidas();
            } else {
                JOptionPane.showMessageDialog(this, "Você já curtiu essa música.");
            }
        } else {
            JOptionPane.showMessageDialog(this, "Selecione uma música para curtir.");
        }
    }

    private void descurtirMusica() {
        Musica musicaSelecionada = listaCurtidas.getSelectedValue();
        if (musicaSelecionada != null) {
            boolean sucesso = curtidaController.descurtir(usuarioId, musicaSelecionada.getId());
            if (sucesso) {
                JOptionPane.showMessageDialog(this, "Música descurtida!");
                carregarMusicasCurtidas();
            } else {
                JOptionPane.showMessageDialog(this, "Você ainda não curtiu essa música.");
            }
        } else {
            JOptionPane.showMessageDialog(this, "Selecione uma música para descurtir.");
        }
    }

    private void criarNovaPlaylist() {
        String nome = JOptionPane.showInputDialog(this, "Digite o nome da nova playlist:");
        if (nome != null && !nome.trim().isEmpty()) {
            boolean sucesso = playlistController.criarPlaylist(usuarioId, nome.trim());
            if (sucesso) {
                JOptionPane.showMessageDialog(this, "Playlist criada com sucesso!");
                carregarPlaylists();
            } else {
                JOptionPane.showMessageDialog(this, "Erro ao criar playlist.");
            }
        }
    }

    private void adicionarMusicaNaPlaylist() {
        Musica musicaSelecionada = listaMusicas.getSelectedValue();
        Playlist playlistSelecionada = listaPlaylists.getSelectedValue();

        if (musicaSelecionada == null) {
            JOptionPane.showMessageDialog(this, "Selecione uma música para adicionar.");
            return;
        }
        if (playlistSelecionada == null) {
            JOptionPane.showMessageDialog(this, "Selecione uma playlist para adicionar a música.");
            return;
        }

        try {
            boolean sucesso = playlistController.adicionarMusicaNaPlaylist(playlistSelecionada.getId(), musicaSelecionada.getId());
            if (sucesso) {
                JOptionPane.showMessageDialog(this, "Música adicionada à playlist com sucesso!");
                carregarMusicasDaPlaylistSelecionada();
            } else {
                JOptionPane.showMessageDialog(this, "Essa música já está na playlist.");
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Erro ao adicionar música na playlist: " + ex.getMessage());
        }
    }

    // remover música da playlist selecionada
    private void removerMusicaDaPlaylist() {
        Musica musicaSelecionada = listaMusicasDaPlaylist.getSelectedValue();
        Playlist playlistSelecionada = listaPlaylists.getSelectedValue();

        if (musicaSelecionada == null) {
            JOptionPane.showMessageDialog(this, "Selecione uma música da playlist para remover.");
            return;
        }
        if (playlistSelecionada == null) {
            JOptionPane.showMessageDialog(this, "Selecione uma playlist.");
            return;
        }

        try {
            boolean sucesso = playlistController.removerMusicaDaPlaylist(playlistSelecionada.getId(), musicaSelecionada.getId());
            if (sucesso) {
                JOptionPane.showMessageDialog(this, "Música removida da playlist com sucesso!");
                carregarMusicasDaPlaylistSelecionada();
            } else {
                JOptionPane.showMessageDialog(this, "Erro ao remover música da playlist.");
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Erro ao remover música da playlist: " + ex.getMessage());
        }
    }

    // excluir playlist inteira
    private void excluirPlaylist() {
        Playlist playlistSelecionada = listaPlaylists.getSelectedValue();
        if (playlistSelecionada == null) {
            JOptionPane.showMessageDialog(this, "Selecione uma playlist para excluir.");
            return;
        }

        int confirmar = JOptionPane.showConfirmDialog(this,
                "Tem certeza que deseja excluir a playlist '" + playlistSelecionada.getNome() + "'?",
                "Confirmação de Exclusão", JOptionPane.YES_NO_OPTION);

        if (confirmar == JOptionPane.YES_OPTION) {
            try {
                boolean sucesso = playlistController.excluirPlaylist(playlistSelecionada.getId());
                if (sucesso) {
                    JOptionPane.showMessageDialog(this, "Playlist excluída com sucesso!");
                    carregarPlaylists();
                    listaMusicasDaPlaylistModel.clear();
                } else {
                    JOptionPane.showMessageDialog(this, "Erro ao excluir playlist.");
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Erro ao excluir playlist: " + ex.getMessage());
            }
        }
    }
}
