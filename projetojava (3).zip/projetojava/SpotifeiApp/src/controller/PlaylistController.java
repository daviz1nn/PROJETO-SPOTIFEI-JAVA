package controller;

import dao.PlaylistDAO;
import model.Playlist;
import java.util.List;
import java.util.ArrayList;

public class PlaylistController {
    private PlaylistDAO playlistDAO;

    public PlaylistController() {
        try {
            this.playlistDAO = new PlaylistDAO();
        } catch (Exception e) {
            System.err.println("Erro ao inicializar PlaylistDAO: " + e.getMessage());
            this.playlistDAO = null;
        }
    }

    public boolean removerMusicaDaPlaylist(int idPlaylist, int idMusica) {
        if (playlistDAO != null) {
            try {
                return playlistDAO.removerMusicaDaPlaylist(idPlaylist, idMusica);
            } catch (Exception e) {
                System.err.println("Erro ao remover música: " + e.getMessage());
                return false;
            }
        }
        return false;
    }

    public boolean criarPlaylist(int usuarioId, String nome) {
        return playlistDAO != null && playlistDAO.criarPlaylist(usuarioId, nome);
    }

    public List<Playlist> getPlaylistsPorUsuario(int usuarioId) {
        return playlistDAO != null ? playlistDAO.getPlaylistsPorUsuario(usuarioId) : new ArrayList<>();
    }

    public boolean adicionarMusicaNaPlaylist(int idPlaylist, int idMusica) {
        return playlistDAO != null && playlistDAO.adicionarMusicaNaPlaylist(idPlaylist, idMusica);
    }

    public List<Integer> getIdsMusicasPorPlaylist(int idPlaylist) {
        return playlistDAO != null ? playlistDAO.getIdsMusicasPorPlaylist(idPlaylist) : new ArrayList<>();
    }

    // método para excluir playlist
    public boolean excluirPlaylist(int idPlaylist) {
        if (playlistDAO != null) {
            try {
                return playlistDAO.excluirPlaylist(idPlaylist);
            } catch (Exception e) {
                System.err.println("Erro ao excluir playlist: " + e.getMessage());
            }
        }
        return false;
    }
}
