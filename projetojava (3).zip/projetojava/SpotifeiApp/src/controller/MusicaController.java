package controller;

import dao.MusicaDAO;
import model.Musica;
import java.util.List;
import java.util.ArrayList;

public class MusicaController {
    private MusicaDAO musicaDAO;

    public MusicaController() {
        this.musicaDAO = new MusicaDAO();
    }

    
    public List<Musica> getMusicasPorPlaylist(int idPlaylist) {
        try {
            return musicaDAO.getMusicasPorPlaylist(idPlaylist);
        } catch (Exception e) {
            System.err.println("Erro ao buscar músicas da playlist: " + e.getMessage());
            return new ArrayList<>(); // Retorna lista vazia em caso de erro
        }
    }

    
    public List<Musica> buscarMusicas(String termo) throws Exception {
        return musicaDAO.buscarMusicas(termo);
    }

    public List<Musica> getMusicasPorIds(List<Integer> idsMusicas) throws Exception {
        return musicaDAO.getMusicasPorIds(idsMusicas);
    }
}