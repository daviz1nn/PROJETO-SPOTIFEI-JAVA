package controller;

import dao.CurtidaDAO;
import java.util.List;

public class CurtidaController {
    private CurtidaDAO curtidaDAO;

    public CurtidaController() {
        this.curtidaDAO = new CurtidaDAO();
    }

    // Método para curtir 
    public boolean curtir(int usuarioId, int musicaId) {
        return curtidaDAO.curtir(usuarioId, musicaId);
    }

    // Método para descurtir
    public boolean descurtir(int usuarioId, int musicaId) {
        return curtidaDAO.descurtir(usuarioId, musicaId);
    }

    // Método para verificar músicas curtidas
    public List<Integer> getMusicasCurtidas(int usuarioId) {
        return curtidaDAO.getMusicasCurtidas(usuarioId);
    }
}